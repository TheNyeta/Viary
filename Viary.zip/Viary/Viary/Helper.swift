//
//  Helper.swift
//  Viary
//
//  Created by Timothy on 19/01/22.
//  Copyright © 2022 Timothy. All rights reserved.
//

import Foundation

class Helper {
    
    static func haveNumber(str: String) -> Bool {
        
        for i in str {
            if i >= "0" && i <= "9" {
                return true
            }
        }
        
        return false
    }
    
    static func haveAlphabet(str: String) -> Bool {
        
        for i in str {
            if i >= "a" && i <= "z" || i >= "A" && i <= "Z" {
                return true
            }
        }
        
        return false
    }
}
