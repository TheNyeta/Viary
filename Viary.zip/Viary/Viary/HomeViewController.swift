//
//  HomeViewController.swift
//  Viary
//
//  Created by Timothy on 18/01/22.
//  Copyright © 2022 Timothy. All rights reserved.
//

import UIKit
import CoreData

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var greetLbl: UILabel!
    
    @IBOutlet weak var diaryTableView: UITableView!
    
    var context:NSManagedObjectContext!
    var name: String?
    var index = 0
    
    var diaryList = [Diary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        greetLbl.text = "Hello, \(name!)"
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
        
        diaryTableView.delegate = self
        diaryTableView.dataSource = self
        
        loadData()
    }

//    func alert(msg:String, handler:((UIAlertAction)-> Void)?) {
//        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .actionSheet)
//
//        let ok = UIAlertAction(title: "Ok", style: .default, handler: handler)
//
//        alert.addAction(ok)
//        present(alert, animated: true, completion: nil)
//    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if(editingStyle == .delete) {
            deleteData(indexPath: indexPath)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        index = indexPath.row
        performSegue(withIdentifier: "goToEdit", sender: self)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return diaryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let diaryCell = tableView.dequeueReusableCell(withIdentifier: "diaryCell", for: indexPath) as! DiaryTableViewCell
        
        diaryCell.titleLbl.text = diaryList[indexPath.row].title
        diaryCell.dateLbl.text = diaryList[indexPath.row].date
        
        
        return diaryCell
    }
    
    func loadData() {
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: "DiaryEntity")
        diaryList.removeAll()
        
        do {
            let result = try context.fetch(req) as! [NSManagedObject]
            
            for diary in result {
                
                if(diary.value(forKey: "user") as! String == name!) {
                    let title = diary.value(forKey: "title") as! String
                    let story = diary.value(forKey: "story") as! String
                    let date = diary.value(forKey: "date") as! String
                    let user = name!
                    
                    diaryList.append(Diary(title: title, story: story, date: date, user: user))
                }
            }
        } catch {
            
        }
        diaryTableView.reloadData()
    }
    
    func addData(title: String, story: String, date: String) {
        
        let entity = NSEntityDescription.entity(forEntityName: "DiaryEntity", in: context)
        
        let diary = NSManagedObject(entity: entity!, insertInto: context)
        diary.setValue(title, forKey: "title")
        diary.setValue(story, forKey: "story")
        diary.setValue(date, forKey: "date")
        diary.setValue(name!, forKey: "user")
        
        do {
            try context.save()
            
        } catch {
            
        }
        loadData()
    }
    
    func editData(title: String, story: String) {
        let toUpdate = diaryList[index].title
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: "DiaryEntity")
        
        let predicate = NSPredicate(format: "title == %@", toUpdate)
        
        req.predicate = predicate
        
        do {
            let result = try context.fetch(req) as! [NSManagedObject]
            
            for diary in result {
                
                if(diary.value(forKey: "user") as! String == name!) {
                    diary.setValue(title, forKey: "title")
                    diary.setValue(story, forKey: "story")
                }
            }
            
            try context.save()
            loadData()
            
        } catch {
            
        }
        
    }
    
    func deleteData(indexPath: IndexPath) {
        let toDelete = diaryList[indexPath.row].title
        
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: "DiaryEntity")
        
        let predicate = NSPredicate(format: "title == %@", toDelete)
        
        req.predicate = predicate
        
        do {
            let result = try context.fetch(req) as! [NSManagedObject]
            
            for diary in result {
                
                if(diary.value(forKey: "user") as! String == name!){
                    context.delete(diary)
                }
            }
            
            try context.save()
        } catch {
            
        }
        
        loadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "goToCreate") {
            let dest = segue.destination as! CreateViewController
            dest.delegate = self
            dest.name = name!
        }else if(segue.identifier == "goToEdit") {
            let dest = segue.destination as! EditViewController
            dest.inputTitle = diaryList[index].title
            dest.inputStory = diaryList[index].story
            dest.name = name!
            dest.delegate = self
        }
    }
    
    @IBAction func CreateDiaryBtn(_ sender: Any) {
        performSegue(withIdentifier: "goToCreate", sender: self)
    }
    
    @IBAction func logoutBtn(_ sender: Any) {
        performSegue(withIdentifier: "backToLogin", sender: self)
    }
    
    @IBAction func unwindToHome(_ unwindSegue: UIStoryboardSegue) {
//        let sourceViewController = unwindSegue.source
        // Use data from the view controller which initiated the unwind segue
    }
}

extension HomeViewController:addDiaryDelegate,editDiaryDelegate {
    func addNewDiary(title: String, story: String, date: String) {
        addData(title: title, story: story, date: date)
    }
    
    func editDiary(title: String, story: String) {
        editData(title: title, story: story)
    }
}
