//
//  RegisterViewController.swift
//  Viary
//
//  Created by Timothy on 19/01/22.
//  Copyright © 2022 Timothy. All rights reserved.
//

import UIKit
import CoreData

class RegisterViewController: UIViewController {

    @IBOutlet weak var nameInput: UITextField!
    @IBOutlet weak var emailInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func alert(msg:String, handler:((UIAlertAction)-> Void)?) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .actionSheet)
        
        let ok = UIAlertAction(title: "Ok", style: .default, handler: handler)
        
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func RegisterBtn(_ sender: Any) {
        let name = nameInput.text!
        let email = emailInput.text!
        let pass = passwordInput.text!
        
        if(name == "") {
            alert(msg: "Please fill your name", handler: nil)
        }else if(email == "") {
            alert(msg: "Please fill your email", handler: nil)
        }else if(!email.contains("@") || !email.contains(".")) {
            alert(msg: "Please enter a proper email", handler: nil)
        }
        else if(pass == "") {
            alert(msg: "Please fill your password", handler: nil)
        }else if(pass.count < 8) {
            alert(msg: "Passwword must be more than 8 characters", handler: nil)
        }else if(!Helper.haveAlphabet(str: pass) || !Helper.haveNumber(str: pass)) {
            alert(msg: "Password must be alphanumeric", handler: nil)
        }else{
            
            let entity = NSEntityDescription.entity(forEntityName: "AccountEntity", in: context)

            let account = NSManagedObject(entity: entity!, insertInto: context)
            account.setValue(name, forKey: "name")
            account.setValue(email, forKey: "email")
            account.setValue(pass, forKey: "password")

            do {
                try context.save()
            } catch {

            }
            
            performSegue(withIdentifier: "backToLogin", sender: self)
        }
        
    }
    
    @IBAction func GoLoginBtn(_ sender: Any) {
        performSegue(withIdentifier: "backToLogin", sender: self)
    }
    
}
