//
//  CreateViewController.swift
//  Viary
//
//  Created by Timothy on 18/01/22.
//  Copyright © 2022 Timothy. All rights reserved.
//

import UIKit
import CoreData

protocol addDiaryDelegate {
    func addNewDiary(title: String, story: String, date: String)
}

class CreateViewController: UIViewController {

    @IBOutlet weak var titleInput: UITextField!
    @IBOutlet weak var storyInput: UITextView!
    
    var delegate:addDiaryDelegate?
    var context:NSManagedObjectContext!
    var name: String?
    
    var diaryList = [Diary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        storyInput.layer.borderWidth = 1
        storyInput.layer.borderColor = UIColor.lightGray.cgColor
        storyInput.layer.cornerRadius = 6
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
        
        loadData()
        
    }
    
    func loadData() {
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: "DiaryEntity")
        diaryList.removeAll()
        
        do {
            let result = try context.fetch(req) as! [NSManagedObject]
            
            for diary in result {
                
                if(diary.value(forKey: "user") as! String == name!) {
                    let title = diary.value(forKey: "title") as! String
                    let story = diary.value(forKey: "story") as! String
                    let date = diary.value(forKey: "date") as! String
                    let user = name!
                    
                    diaryList.append(Diary(title: title, story: story, date: date, user: user))
                }
            }
        } catch {
            
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func alert(msg:String, handler:((UIAlertAction)-> Void)?) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .actionSheet)
        
        let ok = UIAlertAction(title: "Ok", style: .default, handler: handler)
        
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func addDiaryBtn(_ sender: Any) {
        let title = titleInput.text!
        let story = storyInput.text!
        var titleVal = 0
        
        if(title == "") {
            alert(msg: "Please fill the title", handler: nil)
        }else if(title.count < 5 || title.count > 30) {
            alert(msg: "Title must be between 5 - 30 characters", handler: nil)
        }else{
            for diary in diaryList{
                if(diary.title == title){
                    titleVal = 1
                }
            }
        }
        
        if(titleVal == 1) {
            alert(msg: "Please use a different title", handler: nil)
        }else if(story == "") {
            alert(msg: "Please fill the story", handler: nil)
        }else{
            let format = DateFormatter()
            format.dateFormat = "dd/MM/yyyy"
            let date = format.string(from: Date())
            
            delegate?.addNewDiary(title: title, story: story, date: date)
            performSegue(withIdentifier: "backToHome", sender: self)
        }
    }
    
    @IBAction func backBtn(_ sender: Any) {
        performSegue(withIdentifier: "backToHome", sender: self)
    }
    

}
