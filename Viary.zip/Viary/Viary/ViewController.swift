//
//  ViewController.swift
//  Viary
//
//  Created by Timothy on 18/01/22.
//  Copyright © 2022 Timothy. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var emailInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    
    var context:NSManagedObjectContext!
    var name:String = ""
    
    var accountList = [Account]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        context = appDelegate.persistentContainer.viewContext
        
        
        
        loadData()
    }

    override func viewWillAppear(_ animated: Bool) {
        emailInput.text = ""
        passwordInput.text = ""
        
        loadData()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func alert(msg:String, handler:((UIAlertAction)-> Void)?) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .actionSheet)
        
        let ok = UIAlertAction(title: "Ok", style: .default, handler: handler)
        
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func LoginBtn(_ sender: Any) {
        
        let email = emailInput.text
        let pass = passwordInput.text
        var emailVal = 0
        var passVal = 0
        
        if(email == "") {
            alert(msg: "Please fill your email", handler: nil)
        }else if(pass == "") {
            alert(msg: "Please fill your password", handler: nil)
        }else{
            loadData()
            
            for account in accountList{
                
                if(account.email == email) {
                    emailVal = 1
                    if(account.password == pass) {
                        name = account.name
                        passVal = 1
                        performSegue(withIdentifier: "goToHome", sender: self)
                    }
                }
                
            }
            
            if(emailVal == 0) {
                alert(msg: "Email not registered", handler: nil)
            }else if(passVal == 0) {
                alert(msg: "Password dosen't match", handler: nil)
            }
            
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "goToHome") {
            let dest = segue.destination as! HomeViewController
            dest.name = name
        }else if(segue.identifier == "goToRegister") {}
        
    }
    
    func loadData() {
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: "AccountEntity")
        accountList.removeAll()
        
        do {
            let result = try context.fetch(req) as! [NSManagedObject]
            
            for account in result {
                let name = account.value(forKey: "name") as! String
                let email = account.value(forKey: "email") as! String
                let password = account.value(forKey: "password") as! String
                
                accountList.append(Account(name: name, email: email, password: password))
            }
        } catch {
            
        }
    }
    
    @IBAction func GoRegisterBtn(_ sender: Any) {
        performSegue(withIdentifier: "goToRegister", sender: self)
    }
    
    @IBAction func unwindToLogin(_ unwindSegue: UIStoryboardSegue) {
//        let sourceViewController = unwindSegue.source
        // Use data from the view controller which initiated the unwind segue
    }
    
}

