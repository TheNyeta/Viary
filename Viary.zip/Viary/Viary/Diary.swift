//
//  Diary.swift
//  Viary
//
//  Created by Timothy on 18/01/22.
//  Copyright © 2022 Timothy. All rights reserved.
//

import Foundation
struct Diary {
    var title: String
    var story: String
    var date: String
    var user: String
}
