//
//  Account.swift
//  Viary
//
//  Created by Timothy on 19/01/22.
//  Copyright © 2022 Timothy. All rights reserved.
//

import Foundation

struct Account {
    var name: String
    var email: String
    var password: String
}
